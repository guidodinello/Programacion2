#ifndef _B_H
#define _B_H

void b(char p1[100], char p2[100], char concat[100]);

#endif
