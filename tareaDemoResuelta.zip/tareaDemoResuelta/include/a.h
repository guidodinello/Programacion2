#ifndef _A_H
#define _A_H

float a(float base, float altura);

#endif
