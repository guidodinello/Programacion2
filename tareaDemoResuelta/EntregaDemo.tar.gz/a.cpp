
float a(float base, float altura) {
    return base * altura / 2;
}
